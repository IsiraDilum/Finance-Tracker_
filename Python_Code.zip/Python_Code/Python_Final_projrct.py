import json
from datetime import datetime
import tkinter as tk
from tkinter import ttk, simpledialog, messagebox
from tkcalendar import DateEntry
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from PIL import Image, ImageTk

show_table_1st_time = 0
# Variable to track if the table has been shown for the first time
print("Creator of the app is K.A.I.Dlium 🖋️")#creater  Dilum
print("Index Number : DSE-A-022")
print("Orugodawaththa (AETI)")
class Entry:
    # Class to represent a financial entry
    def __init__(self, entry_type, amount, category, date):
        self.entry_type = entry_type
        self.amount = amount
        self.category = category
        self.date = date

class FinanceTracker:
    # Class to manage financial entries and their storage
    def __init__(self, root):
        self.file_path = 'Finance_Data_file.txt'
        self.entries = []
        self.selected_entries = set()
        self.load_data_from_file()

    def add_entry(self, entry_type, amount, category, date):
        # Create a new entry and append it to the list
        new_entry = Entry(entry_type, amount, category, date)
        self.entries.append(new_entry)
        # Show the table if it's the first time?
        if show_table_1st_time == 1:
            self.show_entries_in_table()
        self.save_data_to_file()

    def load_data_from_file(self):
        try:
            with open(self.file_path, 'r') as file:
                data = json.load(file)
                self.entries = [Entry(
                    entry['entry_type'],
                    entry['amount'],
                    entry['category'],
                    datetime.strptime(entry['date'], '%Y-%m-%d'))
                    for entry in data['entries']]
        except (FileNotFoundError, json.JSONDecodeError):
            pass

    def save_data_to_file(self):
        # Save data to the json file
        data = {'entries': [{'entry_type': entry.entry_type,
                             'amount': entry.amount,
                             'category': entry.category,
                             'date': entry.date.strftime('%Y-%m-%d')}
                            for entry in self.entries]}
        with open(self.file_path, 'w') as file:
            json.dump(data, file, indent=2)
    def calculate_totals(self):
        # Calculate total income and expenses and return
        total_income = sum(entry.amount for entry in self.entries if entry.entry_type == "Income")
        total_expenses = sum(entry.amount for entry in self.entries if entry.entry_type == "Expense")
        return total_income, total_expenses

    def view_summary(self, month, year):
        # Filter entries for the specified month and year
        filtered_entries = [entry for entry in self.entries if entry.date.month == month and entry.date.year == year]
        return filtered_entries

    def delete_selected_entries(self, selected_items):
        # Delete selected entries from the list
        if not selected_items:
            return

        for item in selected_items:
            entry_index = int(item.split('I')[1])
            if 0 <= entry_index < len(self.entries):
                del self.entries[entry_index]
    def show_pie_chart(self):
        # Function to display a pie chart showing monthly income and expense
        monthly_summary = {}
        for entry in self.tracker.entries:
            key = f"{entry.date.strftime('%B %Y')} - {entry.entry_type}"
            monthly_summary[key] = monthly_summary.get(key, 0) + entry.amount

        labels = list(monthly_summary.keys())
        values = list(monthly_summary.values())

        fig, ax = plt.subplots()
        ax.pie(values, labels=labels, autopct='%1.1f%%', startangle=90, colors=['green', 'red'])
        ax.axis('equal')  # Equal aspect ratio ensures that pie is drawn as a circle.

        canvas = FigureCanvasTkAgg(fig, master=self.root)
        canvas_widget = canvas.get_tk_widget()
        canvas_widget.grid(row=0, column=2, rowspan=6, padx=10, pady=10, sticky="ne")
        canvas.draw()

class FinanceTrackerGUI:
    #Add GUI part of the Finance Tracker App
    def __init__(self, root):
        self.tracker = FinanceTracker(root)
        self.root = root
        self.root.title("Finance Tracker")
        self.create_widgets()
        self.istable_open = "NO"
        self.root.configure(bg='light blue')
        # Open the image
        image = Image.open('icon.png')
        # Convert the image to a Tkinter PhotoImage object
        icon = ImageTk.PhotoImage(image)
        # Set the icon
        root.iconphoto(True, icon)

    def create_widgets(self):
        #Add button/Label/textbox
        ttk.Label(self.root, text="Finance Tracker", font=("Helvetica", 16),background='light blue').grid(row=0, column=1, pady=10, sticky="w")
        ttk.Label(self.root, text="Entry Type:",background='light blue').grid(row=1, column=0, padx=10, pady=5, sticky="w")
        entry_types = ["Income", "Expense"]
        self.entry_type_var = tk.StringVar(value=entry_types[0])
        self.entry_type = ttk.Combobox(self.root, textvariable=self.entry_type_var, values=entry_types,style="TCombobox")
        self.entry_type.grid(row=1, column=1, padx=10, pady=5, sticky="w")
        ttk.Label(self.root, text="Amount:",background='light blue').grid(row=2, column=0, padx=10, pady=5, sticky="w")
        self.amount = tk.Entry(self.root, bg='white', fg='black')
        self.amount.grid(row=2, column=1, padx=10, pady=5, sticky="w")
        ttk.Label(self.root, text="Category:",background='light blue').grid(row=3, column=0, padx=10, pady=5, sticky="w")
        self.category = tk.Entry(self.root, bg='white', fg='black')
        self.category.grid(row=3, column=1, padx=10, pady=5, sticky="w")
        ttk.Label(self.root, text="Date:",background='light blue').grid(row=4, column=0, padx=10, pady=5, sticky="w")
        self.date = DateEntry(self.root,width=12, background='#3498DB', foreground='white', borderwidth=2, date_pattern="yyyy-mm-dd")
        self.date.grid(row=4, column=1, padx=10, pady=5, sticky="w")
        #buttons
        ttk.Button(self.root, text="Add Entry", command=self.add_entry).grid(                    row=5, column=0, pady=5, sticky="w")
        ttk.Button(self.root, text="View Entries", command=self.view_entries).grid(              row=5, column=1, pady=5, sticky="w")
        ttk.Button(self.root, text="Calculate Totals", command=self.calculate_totals).grid(      row=2, column=3, pady=5, sticky="w")
        ttk.Button(self.root, text="View Summary", command=self.view_summary).grid(              row=1, column=3, pady=5, sticky="w")
        ttk.Button(self.root, text="Delete Selected", command=self.delete_selected_entries).grid(row=5, column=3, pady=5, sticky="w")
        ttk.Button(self.root, text="Exit", command=self.exit).grid(                              row=5, column=4, pady=5, sticky="w")

        self.running_text_var = tk.StringVar()
        running_text_label = ttk.Label(self.root, textvariable=self.running_text_var, font=('Helvetica', 8),foreground="gray",background="Light blue")
        running_text_label.grid(row=10, column=1, columnspan=3, pady=5)
        self.blink_running_text()
    def add_entry(self):
        # Function to add a new entry when the "Add Entry" button before clicked
        entry_type = self.entry_type_var.get()
        amount = self.get_entry_value(self.amount, float)
        category = self.category.get()
        date = self.date.get_date()

        if entry_type and amount is not None and category and date:
            self.tracker.add_entry(entry_type, amount, category, date)
            self.amount.delete(0, tk.END)
            self.category.delete(0, tk.END)
            if self.istable_open == "Yes":
                self.show_entries_in_table()
        else:
            self.show_message("Please fill in all fields.")

    def view_entries(self):
        # Function to show entries in a table when the "View Entries" button before clicked
        self.show_entries_in_table()
        self.istable_open = "Yes"

    def calculate_totals(self):
        # Function to calculate and display total income, expenses, and balance
        total_income, total_expenses = self.tracker.calculate_totals()
        self.show_message(
            f"Total Income: {total_income}\nTotal Expenses: {total_expenses}\nLast balance: {total_income - total_expenses}")

    def view_summary(self):
        # Function to view a summary of entries for a specific month and year
        month_year_window = tk.Toplevel(self.root)
        month_year_window.title("Enter Month and Year")

        ttk.Label(month_year_window, text="Enter the month:").grid(row=0, column=0, padx=10, pady=5, sticky="w")
        month_entry = tk.Entry(month_year_window, bg='white', fg='black')
        month_entry.grid(row=0, column=1, padx=10, pady=5, sticky="w")

        ttk.Label(month_year_window, text="Enter the year:").grid(row=1, column=0, padx=10, pady=5, sticky="w")
        year_entry = tk.Entry(month_year_window, bg='white', fg='black')
        year_entry.grid(row=1, column=1, padx=10, pady=5, sticky="w")

        def submit_month_year():
            month = self.get_entry_value(month_entry, int)
            year = self.get_entry_value(year_entry, int)
            if month is not None and year is not None:
                summary = self.tracker.view_summary(month, year)
                month_year_window.destroy()

                if summary:
                    self.show_entries_in_table(summary)
                else:
                    self.show_message("No entries found for the specified month and year.")

        ttk.Button(month_year_window, text="Submit", command=submit_month_year).grid(row=2, column=1, columnspan=2, pady=5, sticky="w")


    def delete_selected_entries(self):
        # Function to delete selected entries from the table
        selected_items = self.tree.selection()

        if not selected_items:
            self.show_message("No entries selected. Please select entries to delete.")
            return

        for item in selected_items:
            try:
                entry_index = int(self.tree.item(item, "tags")[0])
                if 0 <= entry_index < len(self.tracker.entries):
                    del self.tracker.entries[entry_index]
                else:
                    self.show_message(f"Invalid entry index: {entry_index}. Entry not found.")
            except (ValueError, IndexError, TypeError):
                self.show_message(f"Error processing entry index for item: {item}")

        self.show_entries_in_table()
        self.show_entries_in_table()
        self.show_message("Selected entries deleted successfully.")

    def exit(self):
        # Function to exit the application
        self.root.destroy()

    def ask_user(self, prompt):
        # Function to prompt the user for input
        return simpledialog.askstring("Input", prompt)

    def get_entry_value(self, entry, data_type=str):
        if isinstance(entry, tk.Entry):
            value = entry.get().strip()
        else:
            value = entry.strip()

        if not value:
            self.show_message("Please fill in all fields.")
            return None
        try:
            return data_type(value)
        except ValueError:
            self.show_message(f"Invalid {data_type.__name__} format.")
            return None

    def show_pie_chart(self):
        # Function to display a pie chart showing total income and expense
        summary = {'Income': 0, 'Expense': 0}

        for entry in self.tracker.entries:
            summary[entry.entry_type] += entry.amount

        labels = list(summary.keys())
        values = list(summary.values())

        fig, ax = plt.subplots(figsize=(2,1))
        ax.pie(values, labels=labels, autopct='%1.1f%%', startangle=90, colors=['green', 'red'],
               textprops={'fontsize': 8})
        ax.axis('equal')
        fig.patch.set_facecolor('lightblue')
        canvas = FigureCanvasTkAgg(fig, master=self.root)
        canvas_widget = canvas.get_tk_widget()
        canvas_widget.grid(row=1, column=2, rowspan=6, padx=10, pady=10, sticky="ne")
        canvas.draw()

    def show_entries_in_table(self, entries=None):
        # display entries in a table
        if entries is None:
            entries = self.tracker.entries

        self.tree = ttk.Treeview(self.root)
        self.tree["columns"] = ("Type", "Amount", "Category", "Date")
        self.tree.column("#0", width=0, stretch=tk.NO)
        self.tree.column("Type", anchor=tk.W, width=100)
        self.tree.column("Amount", anchor=tk.W, width=100)
        self.tree.column("Category", anchor=tk.W, width=100)
        self.tree.column("Date", anchor=tk.W, width=100)

        self.tree.heading("#0", text="", anchor=tk.W)
        self.tree.heading("Type", text="Type", anchor=tk.W)
        self.tree.heading("Amount", text="Amount", anchor=tk.W)
        self.tree.heading("Category", text="Category", anchor=tk.W)
        self.tree.heading("Date", text="Date", anchor=tk.W)

        for index, entry in enumerate(entries):
            item = self.tree.insert("", tk.END, values=(
                entry.entry_type, entry.amount, entry.category, entry.date.strftime('%d/%m/%Y')))
            self.tree.item(item, tags=(index,))
        self.tree.grid(row=7, column=1, columnspan=5, pady=10, sticky="w")
        self.show_pie_chart()
    def show_message(self, message):
        # show a message using a pop-up dialog
        messagebox.showinfo("Finance Tracker", message)

    def blink_running_text(self):
        current_text = self.running_text_var.get()
        if current_text == "K.A.I.Dilum":
            self.running_text_var.set("DSE-A-022")
        else:
            self.running_text_var.set("K.A.I.Dilum")

        self.root.after(1500, self.blink_running_text)  # Change the text every 1500 milliseconds


def main():
    # Main function
    root = tk.Tk()
    app = FinanceTrackerGUI(root)
    root.mainloop()

if __name__ == "__main__":
    # Run the main function if the script is executed directly
    main()